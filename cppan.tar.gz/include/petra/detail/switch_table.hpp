// Copyright Jacqueline Kay 2017
// Distributed under the MIT License.
// See accompanying LICENSE.md or https://opensource.org/licenses/MIT

#pragma once

namespace petra {
  namespace detail {}  // namespace detail
}  // namespace petra
